#!binbash
uvicorn mainapp --host 0.0.0.0 --port $PORT